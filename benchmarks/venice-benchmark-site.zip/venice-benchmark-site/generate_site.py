#!/usr/bin/env python3
"""Generate the benchmark website directly via Fable 5 on Venice API."""
import os, time, requests, json, re

API_URL = "https://api.venice.ai/api/v1/chat/completions"
API_KEY = os.environ.get("VENICE_INFERENCE_KEY") or os.environ.get("VENICE_API_KEY")
if not API_KEY:
    raise RuntimeError("Set VENICE_INFERENCE_KEY or VENICE_API_KEY")
MODEL = "claude-fable-5"
OUT = os.path.dirname(os.path.abspath(__file__))

SITE_PROMPT = """You are building a complete static website for a Venice API model benchmark project called "BenchmarkViv".

GOAL
Create a visually stunning, highly interactive static website that showcases benchmark results for Venice API text models. The website must be fun to explore, using modern trending UI/UX design patterns.

REQUIREMENTS
- Single-file index.html (self-contained) plus optional assets. Prefer everything inline in index.html unless separation is cleaner.
- Use modern CSS: glassmorphism, gradients, bento grids, micro-interactions, scroll-driven reveals, animated data visualizations, dark/light mode toggle.
- Include Chart.js from CDN for interactive charts.
- Sections: Hero, Benchmark Overview (3 benchmarks), Interactive Leaderboard, Model Comparison, Cost-Per-Value Analysis, Methodology, Footer.
- Brand: "BenchmarkViv" — tagline: "Long-horizon AI benchmarks for Venice models".
- Models to display (use short display names): GPT-5.5, Fable 5, Opus 4.8, GLM 5.2, DeepSeek V4, MiniMax M3.
- Benchmarks (you design them, focus on long-horizon agentic tasks):
  1. Intent Understanding — models must handle ambiguous multi-turn prompts.
  2. One-Shot UI Generation — generate beautiful functional HTML/CSS/JS from a prompt.
  3. Long-Horizon Agentic Task — multi-step coding/planning with follow-up edits.
- Include a cost-per-value scatter plot: x-axis = cost per 1K tokens, y-axis = quality score, bubble size = speed.
- The site should read data/results.json and populate charts/tables dynamically. Include fallback sample data embedded in the JS so it still works if results.json is missing.
- Make it Railway-deployable: static files, no build step, environment variable only for the runner (not the site).
- No API keys in HTML.

OUTPUT
Return only the complete index.html content inside a ```html code block.
"""

RUNNER_PROMPT = """You are writing a Python benchmark runner for the "BenchmarkViv" project.

GOAL
Run three long-horizon benchmarks against the Venice API and write results to data/results.json.

MODELS (exact Venice model IDs):
- openai-gpt-55 (display: GPT-5.5)
- claude-fable-5 (display: Fable 5)
- claude-opus-4-8 (display: Opus 4.8)
- zai-org-glm-5-2 (display: GLM 5.2)
- deepseek-v4-pro (display: DeepSeek V4)
- minimax-m3-preview (display: MiniMax M3)

BENCHMARKS
1. Intent Understanding
   Prompt: "I need something built for my team but I'm not sure what. We are overwhelmed by Slack notifications and duplicate work. Suggest a solution and ask clarifying questions before assuming details."
   Score manually later based on: asks clarifying questions (0-40), structured proposal (0-30), avoids hallucination (0-30). Total 100.

2. One-Shot UI Generation
   Prompt: "Generate a single self-contained HTML file for a dark-mode dashboard card showing a user's daily focus score, weekly trend sparkline, and a 'Start Focus' button. Use only HTML/CSS/JS. No external images."
   For the runner, just capture the response and length. Real scoring is manual/LLM-judge. Score placeholder 70-95 based on heuristics (contains html, css, js, button, score text).

3. Long-Horizon Agentic Task
   Prompt: "Plan and outline a multi-step system to build an AI research assistant that: (1) monitors arXiv for papers, (2) summarizes them, (3) stores them in a vector DB, (4) answers user questions with citations. List the steps, tools needed, and potential failure modes."
   Score based on: step count >= 4, mentions tools, mentions failure modes. Total 100.

RUNNER REQUIREMENTS
- Read API key from VENICE_INFERENCE_KEY env var.
- POST to https://api.venice.ai/api/v1/chat/completions
- For each model, run all 3 benchmarks with max_tokens=2048, temperature=0.5.
- Capture: status, latency, prompt_tokens, completion_tokens, total_tokens, raw_response.
- Estimate cost: use the pricing from the Venice /models endpoint if available, otherwise approximate: input $/1M and output $/1M. For this runner, use approximate Venice pricing (you can hardcode reasonable per-model rates).
- Add rate limiting: sleep 1 second between calls.
- Save to data/results.json with structure: { "generated_at": ISO timestamp, "models": [...], "benchmarks": [...], "results": [{model_id, benchmark_id, score, latency, prompt_tokens, completion_tokens, total_tokens, estimated_cost_usd}] }.
- Include argparse: --dry-run (generate sample data, no API calls), --run-real (actual API calls). Default to dry-run.
- Print progress and total estimated cost before real run.
- Handle errors gracefully; continue if one model fails.

OUTPUT
Return only the complete Python script inside a ```python code block.
"""

def call_fable(prompt, max_tokens=16000):
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
        "temperature": 0.5,
    }
    start = time.time()
    resp = requests.post(API_URL, headers=headers, json=payload, timeout=600)
    elapsed = time.time() - start
    if resp.status_code != 200:
        raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:500]}")
    data = resp.json()
    content = data["choices"][0]["message"].get("content", "")
    usage = data.get("usage", {})
    print(f"Call: {elapsed:.1f}s, tokens: {usage.get('total_tokens',0)}")
    return content

def extract_block(text, lang):
    pat = rf"```{lang}\s*(.*?)```"
    m = re.search(pat, text, re.DOTALL | re.IGNORECASE)
    if m:
        return m.group(1).strip()
    m = re.search(r"```\s*(.*?)```", text, re.DOTALL)
    if m:
        return m.group(1).strip()
    return text.strip()

def main():
    print("=== Generating index.html with Fable 5 ===")
    site_text = call_fable(SITE_PROMPT, max_tokens=16000)
    html = extract_block(site_text, "html")
    with open(os.path.join(OUT, "index.html"), "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Saved index.html ({len(html)} chars)")

    print("\n=== Generating run_benchmarks.py with Fable 5 ===")
    runner_text = call_fable(RUNNER_PROMPT, max_tokens=12000)
    py = extract_block(runner_text, "python")
    with open(os.path.join(OUT, "run_benchmarks.py"), "w", encoding="utf-8") as f:
        f.write(py)
    print(f"Saved run_benchmarks.py ({len(py)} chars)")

    # Create README
    readme = """# BenchmarkViv

Long-horizon benchmark suite and interactive showcase for Venice API models.

## Local preview

```bash
cd /Users/vivgatesai/.openclaw/workspace/benchmarks/venice-benchmark-site
python3 -m http.server 8080
```

Open http://localhost:8080

## Run benchmarks

```bash
export VENICE_INFERENCE_KEY=<your-key>
python3 run_benchmarks.py --dry-run   # sample data, $0
python3 run_benchmarks.py --run-real  # real API calls (~$2-5)
```

## Deploy to Railway

Add this repo to Railway as a static site. Serve the root directory.
No build step required.
"""
    with open(os.path.join(OUT, "README.md"), "w", encoding="utf-8") as f:
        f.write(readme)

if __name__ == "__main__":
    main()
