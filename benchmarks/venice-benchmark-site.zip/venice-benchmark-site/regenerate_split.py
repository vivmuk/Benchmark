#!/usr/bin/env python3
"""Regenerate BenchmarkViv site as split files to avoid Fable output truncation."""
import os, time, requests, re

API_URL = "https://api.venice.ai/api/v1/chat/completions"
API_KEY = os.environ.get("VENICE_INFERENCE_KEY") or os.environ.get("VENICE_API_KEY")
if not API_KEY:
    raise RuntimeError("Set VENICE_INFERENCE_KEY or VENICE_API_KEY")
MODEL = "claude-fable-5"
OUT = os.path.dirname(os.path.abspath(__file__))

HTML_PROMPT = """Generate the complete index.html file for "BenchmarkViv", a Venice API model benchmark showcase site.

This file must ONLY contain the HTML structure. All styling is in assets/styles.css and all JS is in assets/app.js (loaded via <script src="assets/app.js"> at the end of <body>).

Requirements for the HTML:
- DOCTYPE, html with data-theme="dark", head with meta, title "BenchmarkViv", link to assets/styles.css, Chart.js CDN, and fonts.
- Body sections in order:
  1. Navigation bar with logo "BenchmarkViv", links: Benchmarks, Leaderboard, Methodology, and a dark/light theme toggle button.
  2. Hero section with big headline "Long-Horizon AI Benchmarks for Venice Models", tagline, animated gradient/glassmorphism background, and CTA buttons.
  3. Stats row (bento grid) showing: Models Tested, Benchmarks, Total Evaluations, Avg Cost per Run.
  4. Benchmarks section with 3 cards: Intent Understanding, One-Shot UI Generation, Long-Horizon Agentic Task. Each card has an icon, title, description, and difficulty chips.
  5. Leaderboard section with a canvas for Chart.js bar chart (id="leaderboardChart") and a sortable/filterable table (id="leaderboardTable").
  6. Cost-Per-Value section with canvas id="costValueChart" and a brief explanation.
  7. Model Comparison section with model cards for: GPT-5.5, Fable 5, Opus 4.8, GLM 5.2, DeepSeek V4, MiniMax M3. Each card shows name, description placeholder, and sparkline canvas.
  8. Methodology section explaining the three benchmark categories and scoring.
  9. Footer with credits and "Generated with Fable 5".
- Include a hidden script element or data attribute that app.js can read for fallback data? Better: app.js contains fallback data. HTML just provides containers.
- Add a data-status element id="dataStatus".
- Do not include inline CSS or JS beyond what's strictly necessary. Keep HTML under 8K tokens of output.

Return only the HTML inside a ```html code block."""

CSS_PROMPT = """Generate the complete CSS file for "BenchmarkViv" benchmark website.

File path context: assets/styles.css

Design direction:
- Modern dark-first design with data-theme="dark" and data-theme="light" support.
- Color palette: deep space blue (#0b0f1a), neon purple (#7c5cff), teal (#00e0b8), hot pink (#ff5c8a), amber (#ffb547), sky blue (#38bdf8), lime (#a3e635). Light theme uses soft grays and whites.
- Glassmorphism cards: translucent backgrounds, backdrop-filter blur, subtle borders.
- Bento grid layout for stats and benchmark cards.
- Micro-interactions: hover lifts, glows, transitions.
- Animated gradient mesh background.
- Scroll-driven reveal animations for sections.
- Responsive layout with CSS Grid and Flexbox.
- Table styling for leaderboard.
- Chart containers with glass cards.
- Buttons with gradients and hover states.

Return only the CSS inside a ```css code block."""

JS_PROMPT = """Generate the complete JavaScript file for "BenchmarkViv".

File path context: assets/app.js. It runs on index.html which loads Chart.js from CDN and assets/styles.css.

Requirements:
- Dark/light theme toggle using data-theme on <html>.
- Mobile nav toggle.
- Fallback sample data embedded in JS for 6 models: GPT-5.5, Fable 5, Opus 4.8, GLM 5.2, DeepSeek V4, MiniMax M3, across 3 benchmarks: intent-understanding, one-shot-ui, long-horizon-agent. Include realistic scores, latencies, tokens, costs.
- Fetch data/results.json; on failure use fallback data. Update #dataStatus with live/fallback indicator.
- Render Chart.js bar chart in #leaderboardChart: average score per model.
- Render Chart.js scatter/bubble chart in #costValueChart: x = cost per run, y = average score, bubble size = average latency.
- Populate and make sortable/filterable #leaderboardTable with columns: Model, Benchmark, Score, Latency, Tokens, Cost.
- Populate model cards in #modelComparison with average scores and mini sparkline canvases (simple line charts).
- Animate counters for stats bento grid when scrolling into view.
- Add scroll reveal observer for sections.
- Keep code clean, vanilla JS, no frameworks.

Return only the JavaScript inside a ```javascript code block."""

def call_fable(prompt, max_tokens=10000):
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
        "temperature": 0.5,
    }
    start = time.time()
    resp = requests.post(API_URL, headers=headers, json=payload, timeout=600)
    elapsed = time.time() - start
    if resp.status_code != 200:
        raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:500]}")
    data = resp.json()
    content = data["choices"][0]["message"].get("content", "")
    usage = data.get("usage", {})
    print(f"Call: {elapsed:.1f}s, tokens: {usage.get('total_tokens',0)}")
    return content

def extract_block(text, lang):
    pat = rf"```{lang}\s*(.*?)```"
    m = re.search(pat, text, re.DOTALL | re.IGNORECASE)
    if m:
        return m.group(1).strip()
    m = re.search(r"```\s*(.*?)```", text, re.DOTALL)
    if m:
        return m.group(1).strip()
    return text.strip()

def save(name, content):
    path = os.path.join(OUT, name)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path

def main():
    print("=== Generating index.html ===")
    html = extract_block(call_fable(HTML_PROMPT, max_tokens=8000), "html")
    save("index.html", html)
    print(f"index.html: {len(html)} chars")

    print("\n=== Generating assets/styles.css ===")
    css = extract_block(call_fable(CSS_PROMPT, max_tokens=9000), "css")
    save("assets/styles.css", css)
    print(f"styles.css: {len(css)} chars")

    print("\n=== Generating assets/app.js ===")
    js = extract_block(call_fable(JS_PROMPT, max_tokens=12000), "javascript")
    save("assets/app.js", js)
    print(f"app.js: {len(js)} chars")

    print("\nDone.")

if __name__ == "__main__":
    main()
