/* ==========================================================================
   BenchmarkViv — assets/app.js
   Vanilla JS. Requires Chart.js (loaded via CDN in index.html).
   ========================================================================== */

(() => {
  "use strict";

  /* ------------------------------------------------------------------ */
  /* Constants & fallback data                                          */
  /* ------------------------------------------------------------------ */

  const DATA_URL = "data/results.json";

  const BENCHMARKS = [
    { id: "intent-understanding", label: "Intent Understanding" },
    { id: "one-shot-ui", label: "One-Shot UI" },
    { id: "long-horizon-agent", label: "Long-Horizon Agent" },
  ];

  const MODEL_COLORS = {
    "GPT-5.5":     "#10a37f",
    "Fable 5":     "#d97757",
    "Opus 4.8":    "#8b5cf6",
    "GLM 5.2":     "#3b82f6",
    "DeepSeek V4": "#0ea5e9",
    "MiniMax M3":  "#f43f5e",
  };

  // Fallback dataset: one row per (model, benchmark).
  // score: 0–100, latency: seconds per run, tokens: total tokens per run,
  // cost: USD per run.
  const FALLBACK_DATA = {
    generated: "2026-07-01T00:00:00Z",
    source: "fallback",
    results: [
      // GPT-5.5
      { model: "GPT-5.5", benchmark: "intent-understanding", score: 91.4, latency: 3.8, tokens: 2450, cost: 0.062 },
      { model: "GPT-5.5", benchmark: "one-shot-ui",          score: 87.9, latency: 11.2, tokens: 8900, cost: 0.198 },
      { model: "GPT-5.5", benchmark: "long-horizon-agent",   score: 82.6, latency: 96.5, tokens: 74200, cost: 1.640 },

      // Fable 5
      { model: "Fable 5", benchmark: "intent-understanding", score: 93.1, latency: 3.2, tokens: 2210, cost: 0.071 },
      { model: "Fable 5", benchmark: "one-shot-ui",          score: 90.5, latency: 9.8, tokens: 8100, cost: 0.226 },
      { model: "Fable 5", benchmark: "long-horizon-agent",   score: 85.9, latency: 88.4, tokens: 69800, cost: 1.870 },

      // Opus 4.8
      { model: "Opus 4.8", benchmark: "intent-understanding", score: 92.3, latency: 5.1, tokens: 2380, cost: 0.118 },
      { model: "Opus 4.8", benchmark: "one-shot-ui",          score: 89.7, latency: 14.6, tokens: 9400, cost: 0.412 },
      { model: "Opus 4.8", benchmark: "long-horizon-agent",   score: 87.2, latency: 121.3, tokens: 81500, cost: 3.150 },

      // GLM 5.2
      { model: "GLM 5.2", benchmark: "intent-understanding", score: 88.6, latency: 2.9, tokens: 2560, cost: 0.021 },
      { model: "GLM 5.2", benchmark: "one-shot-ui",          score: 84.2, latency: 8.7, tokens: 9100, cost: 0.064 },
      { model: "GLM 5.2", benchmark: "long-horizon-agent",   score: 79.8, latency: 84.9, tokens: 71300, cost: 0.480 },

      // DeepSeek V4
      { model: "DeepSeek V4", benchmark: "intent-understanding", score: 89.9, latency: 3.5, tokens: 2620, cost: 0.014 },
      { model: "DeepSeek V4", benchmark: "one-shot-ui",          score: 85.8, latency: 10.4, tokens: 9600, cost: 0.048 },
      { model: "DeepSeek V4", benchmark: "long-horizon-agent",   score: 81.1, latency: 102.7, tokens: 78900, cost: 0.365 },

      // MiniMax M3
      { model: "MiniMax M3", benchmark: "intent-understanding", score: 86.2, latency: 2.4, tokens: 2340, cost: 0.011 },
      { model: "MiniMax M3", benchmark: "one-shot-ui",          score: 81.5, latency: 7.6, tokens: 8400, cost: 0.036 },
      { model: "MiniMax M3", benchmark: "long-horizon-agent",   score: 76.4, latency: 79.2, tokens: 66700, cost: 0.290 },
    ],
  };

  /* ------------------------------------------------------------------ */
  /* State                                                              */
  /* ------------------------------------------------------------------ */

  const state = {
    data: [],
    isLive: false,
    sort: { key: "score", dir: -1 },
    filter: { text: "", benchmark: "all" },
    charts: { leaderboard: null, costValue: null, sparklines: [] },
  };

  /* ------------------------------------------------------------------ */
  /* Helpers                                                            */
  /* ------------------------------------------------------------------ */

  const $  = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  const fmtScore   = (n) => n.toFixed(1);
  const fmtLatency = (n) => `${n.toFixed(1)}s`;
  const fmtTokens  = (n) => n.toLocaleString("en-US");
  const fmtCost    = (n) => `$${n.toFixed(3)}`;

  function benchmarkLabel(id) {
    const b = BENCHMARKS.find((b) => b.id === id);
    return b ? b.label : id;
  }

  function uniqueModels(rows) {
    return [...new Set(rows.map((r) => r.model))];
  }

  function avg(nums) {
    return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
  }

  function modelAggregates(rows) {
    return uniqueModels(rows).map((model) => {
      const mr = rows.filter((r) => r.model === model);
      return {
        model,
        avgScore:   avg(mr.map((r) => r.score)),
        avgLatency: avg(mr.map((r) => r.latency)),
        avgTokens:  avg(mr.map((r) => r.tokens)),
        avgCost:    avg(mr.map((r) => r.cost)),
        scores: BENCHMARKS.map((b) => {
          const row = mr.find((r) => r.benchmark === b.id);
          return row ? row.score : 0;
        }),
      };
    });
  }

  function modelColor(model, alpha = 1) {
    const hex = MODEL_COLORS[model] || "#94a3b8";
    if (alpha >= 1) return hex;
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  function cssVar(name, fallback) {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  }

  function chartTheme() {
    return {
      text: cssVar("--chart-text", document.documentElement.dataset.theme === "light" ? "#334155" : "#cbd5e1"),
      grid: cssVar("--chart-grid", document.documentElement.dataset.theme === "light" ? "rgba(0,0,0,0.08)" : "rgba(255,255,255,0.08)"),
    };
  }

  /* ------------------------------------------------------------------ */
  /* Theme toggle                                                       */
  /* ------------------------------------------------------------------ */

  function initTheme() {
    const root = document.documentElement;
    const stored = localStorage.getItem("bv-theme");
    const prefersLight = window.matchMedia("(prefers-color-scheme: light)").matches;
    root.dataset.theme = stored || (prefersLight ? "light" : "dark");

    const toggle = $("#themeToggle");
    if (!toggle) return;

    const syncLabel = () => {
      const isDark = root.dataset.theme === "dark";
      toggle.setAttribute("aria-label", isDark ? "Switch to light theme" : "Switch to dark theme");
      toggle.textContent = isDark ? "☀️" : "🌙";
    };
    syncLabel();

    toggle.addEventListener("click", () => {
      root.dataset.theme = root.dataset.theme === "dark" ? "light" : "dark";
      localStorage.setItem("bv-theme", root.dataset.theme);
      syncLabel();
      refreshChartThemes();
    });
  }

  function refreshChartThemes() {
    const { text, grid } = chartTheme();
    [state.charts.leaderboard, state.charts.costValue].forEach((chart) => {
      if (!chart) return;
      const scales = chart.options.scales || {};
      Object.values(scales).forEach((axis) => {
        if (axis.ticks) axis.ticks.color = text;
        if (axis.grid)  axis.grid.color = grid;
        if (axis.title) axis.title.color = text;
      });
      if (chart.options.plugins?.legend?.labels) {
        chart.options.plugins.legend.labels.color = text;
      }
      chart.update("none");
    });
  }

  /* ------------------------------------------------------------------ */
  /* Mobile nav                                                         */
  /* ------------------------------------------------------------------ */

  function initNav() {
    const btn = $("#navToggle");
    const nav = $("#siteNav");
    if (!btn || !nav) return;

    btn.addEventListener("click", () => {
      const open = nav.classList.toggle("is-open");
      btn.setAttribute("aria-expanded", String(open));
      btn.classList.toggle("is-active", open);
    });

    // Close nav when a link is clicked (mobile UX).
    nav.addEventListener("click", (e) => {
      if (e.target.matches("a")) {
        nav.classList.remove("is-open");
        btn.classList.remove("is-active");
        btn.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* ------------------------------------------------------------------ */
  /* Data loading                                                       */
  /* ------------------------------------------------------------------ */

  async function loadData() {
    const status = $("#dataStatus");
    try {
      const res = await fetch(DATA_URL, { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      if (!Array.isArray(json.results) || json.results.length === 0) {
        throw new Error("Malformed results.json");
      }
      state.data = json.results;
      state.isLive = true;
    } catch (err) {
      console.warn("[BenchmarkViv] Falling back to embedded data:", err.message);
      state.data = FALLBACK_DATA.results;
      state.isLive = false;
    }

    if (status) {
      status.textContent = state.isLive ? "● Live data" : "● Sample data (offline)";
      status.classList.toggle("status--live", state.isLive);
      status.classList.toggle("status--fallback", !state.isLive);
      status.setAttribute(
        "title",
        state.isLive
          ? `Loaded from ${DATA_URL}`
          : "Could not reach data/results.json — showing embedded sample results."
      );
    }
  }

  /* ------------------------------------------------------------------ */
  /* Leaderboard bar chart                                              */
  /* ------------------------------------------------------------------ */

  function renderLeaderboardChart() {
    const canvas = $("#leaderboardChart");
    if (!canvas || typeof Chart === "undefined") return;

    const aggs = modelAggregates(state.data).sort((a, b) => b.avgScore - a.avgScore);
    const { text, grid } = chartTheme();

    if (state.charts.leaderboard) state.charts.leaderboard.destroy();

    state.charts.leaderboard = new Chart(canvas, {
      type: "bar",
      data: {
        labels: aggs.map((a) => a.model),
        datasets: [{
          label: "Average score",
          data: aggs.map((a) => Number(a.avgScore.toFixed(2))),
          backgroundColor: aggs.map((a) => modelColor(a.model, 0.75)),
          borderColor: aggs.map((a) => modelColor(a.model)),
          borderWidth: 1.5,
          borderRadius: 6,
          maxBarThickness: 64,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => ` Avg score: ${ctx.parsed.y.toFixed(1)} / 100`,
            },
          },
        },
        scales: {
          x: {
            ticks: { color: text },
            grid: { display: false, color: grid },
          },
          y: {
            min: 0,
            max: 100,
            ticks: { color: text },
            grid: { color: grid },
            title: { display: true, text: "Average score", color: text },
          },
        },
      },
    });
  }

  /* ------------------------------------------------------------------ */
  /* Cost vs. value bubble chart                                        */
  /* ------------------------------------------------------------------ */

  function renderCostValueChart() {
    const canvas = $("#costValueChart");
    if (!canvas || typeof Chart === "undefined") return;

    const aggs = modelAggregates(state.data);
    const maxLatency = Math.max(...aggs.map((a) => a.avgLatency), 1);
    const { text, grid } = chartTheme();

    if (state.charts.costValue) state.charts.costValue.destroy();

    state.charts.costValue = new Chart(canvas, {
      type: "bubble",
      data: {
        datasets: aggs.map((a) => ({
          label: a.model,
          data: [{
            x: Number(a.avgCost.toFixed(4)),
            y: Number(a.avgScore.toFixed(2)),
            r: 6 + (a.avgLatency / maxLatency) * 22, // bubble radius from latency
            latency: a.avgLatency,
          }],
          backgroundColor: modelColor(a.model, 0.55),
          borderColor: modelColor(a.model),
          borderWidth: 1.5,
        })),
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "bottom",
            labels: { color: text, usePointStyle: true, boxWidth: 8 },
          },
          tooltip: {
            callbacks: {
              label: (ctx) => {
                const d = ctx.raw;
                return [
                  ` ${ctx.dataset.label}`,
                  ` Avg cost/run: $${d.x.toFixed(3)}`,
                  ` Avg score: ${d.y.toFixed(1)}`,
                  ` Avg latency: ${d.latency.toFixed(1)}s`,
                ];
              },
            },
          },
        },
        scales: {
          x: {
            type: "logarithmic",
            ticks: {
              color: text,
              callback: (v) => `$${Number(v).toFixed(2)}`,
            },
            grid: { color: grid },
            title: { display: true, text: "Average cost per run (log scale)", color: text },
          },
          y: {
            min: 70,
            max: 100,
            ticks: { color: text },
            grid: { color: grid },
            title: { display: true, text: "Average score", color: text },
          },
        },
      },
    });
  }

  /* ------------------------------------------------------------------ */
  /* Leaderboard table (sortable + filterable)                          */
  /* ------------------------------------------------------------------ */

  function initTableControls() {
    const table = $("#leaderboardTable");
    if (!table) return;

    // Sorting via header clicks.
    $$("th[data-sort]", table).forEach((th) => {
      th.style.cursor = "pointer";
      th.setAttribute("role", "button");
      th.setAttribute("tabindex", "0");

      const activate = () => {
        const key = th.dataset.sort;
        if (state.sort.key === key) {
          state.sort.dir *= -1;
        } else {
          state.sort.key = key;
          state.sort.dir = key === "model" || key === "benchmark" ? 1 : -1;
        }
        renderTable();
      };

      th.addEventListener("click", activate);
      th.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          activate();
        }
      });
    });

    // Text filter.
    const search = $("#tableSearch");
    if (search) {
      search.addEventListener("input", () => {
        state.filter.text = search.value.trim().toLowerCase();
        renderTable();
      });
    }

    // Benchmark filter dropdown — populate options if empty.
    const benchSelect = $("#benchmarkFilter");
    if (benchSelect) {
      if (benchSelect.options.length <= 1) {
        BENCHMARKS.forEach((b) => {
          const opt = document.createElement("option");
          opt.value = b.id;
          opt.textContent = b.label;
          benchSelect.appendChild(opt);
        });
      }
      benchSelect.addEventListener("change", () => {
        state.filter.benchmark = benchSelect.value || "all";
        renderTable();
      });
    }
  }

  function renderTable() {
    const table = $("#leaderboardTable");
    if (!table) return;
    const tbody = table.querySelector("tbody") || table.appendChild(document.createElement("tbody"));

    // Filter.
    let rows = state.data.filter((r) => {
      if (state.filter.benchmark !== "all" && r.benchmark !== state.filter.benchmark) return false;
      if (state.filter.text) {
        const haystack = `${r.model} ${benchmarkLabel(r.benchmark)}`.toLowerCase();
        if (!haystack.includes(state.filter.text)) return false;
      }
      return true;
    });

    // Sort.
    const { key, dir } = state.sort;
    rows = rows.slice().sort((a, b) => {
      const av = a[key];
      const bv = b[key];
      if (typeof av === "string") return av.localeCompare(bv) * dir;
      return (av - bv) * dir;
    });

    // Sort indicators on headers.
    $$("th[data-sort]", table).forEach((th) => {
      th.classList.remove("sorted-asc", "sorted-desc");
      if (th.dataset.sort === key) {
        th.classList.add(dir === 1 ? "sorted-asc" : "sorted-desc");
      }
    });

    // Render rows.
    tbody.innerHTML = "";
    const frag = document.createDocumentFragment();

    rows.forEach((r) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>
          <span class="table-dot" style="background:${modelColor(r.model)}"></span>
          ${r.model}
        </td>
        <td>${benchmarkLabel(r.benchmark)}</td>
        <td data-value="${r.score}">${fmtScore(r.score)}</td>
        <td data-value="${r.latency}">${fmtLatency(r.latency)}</td>
        <td data-value="${r.tokens}">${fmtTokens(r.tokens)}</td>
        <td data-value="${r.cost}">${fmtCost(r.cost)}</td>
      `;
      frag.appendChild(tr);
    });

    if (rows.length === 0) {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td colspan="6" class="table-empty">No results match your filters.</td>`;
      frag.appendChild(tr);
    }

    tbody.appendChild(frag);
  }

  /* ------------------------------------------------------------------ */
  /* Model comparison cards + sparklines                                */
  /* ------------------------------------------------------------------ */

  function renderModelCards() {
    const container = $("#modelComparison");
    if (!container) return;

    // Destroy old sparkline charts before re-render.
    state.charts.sparklines.forEach((c) => c.destroy());
    state.charts.sparklines = [];
    container.innerHTML = "";

    const aggs = modelAggregates(state.data).sort((a, b) => b.avgScore - a.avgScore);

    aggs.forEach((a, i) => {
      const card = document.createElement("article");
      card.className = "model-card reveal";
      card.innerHTML = `
        <header class="model-card__header">
          <span class="model-card__rank">#${i + 1}</span>
          <h3 class="model-card__name">
            <span class="table-dot" style="background:${modelColor(a.model)}"></span>
            ${a.model}
          </h3>
        </header>
        <p class="model-card__score">
          <strong>${a.avgScore.toFixed(1)}</strong>
          <span class="model-card__score-label">avg score</span>
        </p>
        <dl class="model-card__meta">
          <div><dt>Latency</dt><dd>${a.avgLatency.toFixed(1)}s</dd></div>
          <div><dt>Cost/run</dt><dd>$${a.avgCost.toFixed(3)}</dd></div>
          <div><dt>Tokens</dt><dd>${Math.round(a.avgTokens).toLocaleString("en-US")}</dd></div>
        </dl>
        <div class="model-card__sparkline">
          <canvas height="48" aria-label="Score trend across benchmarks for ${a.model}"></canvas>
        </div>
      `;
      container.appendChild(card);

      const canvas = card.querySelector("canvas");
      if (canvas && typeof Chart !== "undefined") {
        state.charts.sparklines.push(
          new Chart(canvas, {
            type: "line",
            data: {
              labels: BENCHMARKS.map((b) => b.label),
              datasets: [{
                data: a.scores,
                borderColor: modelColor(a.model),
                backgroundColor: modelColor(a.model, 0.15),
                fill: true,
                tension: 0.35,
                pointRadius: 2.5,
                pointBackgroundColor: modelColor(a.model),
                borderWidth: 2,
              }],
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: { display: false },
                tooltip: {
                  displayColors: false,
                  callbacks: {
                    title: (items) => items[0].label,
                    label: (ctx) => `Score: ${ctx.parsed.y.toFixed(1)}`,
                  },
                },
              },
              scales: {
                x: { display: false },
                y: { display: false, min: 60, max: 100 },
              },
            },
          })
        );
      }
    });
  }

  /* ------------------------------------------------------------------ */
  /* Animated counters (stats bento grid)                               */
  /* ------------------------------------------------------------------ */

  function initCounters() {
    const counters = $$("[data-counter]");
    if (counters.length === 0) return;

    const animate = (el) => {
      const target = parseFloat(el.dataset.counter);
      const decimals = parseInt(el.dataset.decimals || "0", 10);
      const prefix = el.dataset.prefix || "";
      const suffix = el.dataset.suffix || "";
      const duration = parseInt(el.dataset.duration || "1400", 10);
      const start = performance.now();

      const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

      const step = (now) => {
        const t = Math.min((now - start) / duration, 1);
        const value = target * easeOutCubic(t);
        el.textContent = prefix + value.toLocaleString("en-US", {
          minimumFractionDigits: decimals,
          maximumFractionDigits: decimals,
        }) + suffix;
        if (t < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    };

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animate(entry.target);
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });

    counters.forEach((el) => observer.observe(el));
  }

  // Fill dynamic stat values derived from the dataset, if placeholders exist.
  function populateStats() {
    const aggs = modelAggregates(state.data);
    const setCounter = (id, value, decimals = 0) => {
      const el = $(id);
      if (!el) return;
      el.dataset.counter = String(value);
      el.dataset.decimals = String(decimals);
    };

    setCounter("#statModels", uniqueModels(state.data).length);
    setCounter("#statBenchmarks", BENCHMARKS.length);
    setCounter("#statRuns", state.data.length);
    if (aggs.length) {
      setCounter("#statTopScore", Math.max(...aggs.map((a) => a.avgScore)), 1);
    }
  }

  /* ------------------------------------------------------------------ */
  /* Scroll reveal                                                      */
  /* ------------------------------------------------------------------ */

  function initScrollReveal() {
    const targets = $$("section, .reveal");
    if (targets.length === 0) return;

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-revealed");
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

    targets.forEach((el) => {
      el.classList.add("reveal");
      observer.observe(el);
    });
  }

  /* ------------------------------------------------------------------ */
  /* Boot                                                               */
  /* ------------------------------------------------------------------ */

  async function init() {
    initTheme();
    initNav();

    await loadData();

    renderLeaderboardChart();
    renderCostValueChart();
    initTableControls();
    renderTable();
    renderModelCards();

    populateStats();
    initCounters();
    initScrollReveal();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();