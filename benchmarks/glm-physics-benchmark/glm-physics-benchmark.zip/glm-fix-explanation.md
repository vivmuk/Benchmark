html
<!DOCTYPE html>
<html>
<head><title>Fixed Cars</title></head>
<body>
<canvas id="c" width="800" height="400"></canvas>
<script>
const ctx = document.getElementById('c').getContext('2d');
const W = 800, H = 400;

let cars = [
  {x: -60,  y: 290, speed: 2,   color: '#d33', wheelAngle: 0},
  {x: -220, y: 290, speed: 3.2, color: '#33d', wheelAngle: 0}
];

let bg = { clouds: 0, mountains: 0, hills: 0, road: 0 };

const clouds = Array.from({length: 7}, (_, i) => ({
  x: i * 260, y: 25 + (i * 37) % 70, s: 16 + (i * 13) % 12
}));
const mountains = Array.from({length: 8}, (_, i) => ({
  x: i * 200, h: 45 + (i * 29) % 40
}));
const hills = Array.from({length: 10}, (_, i) => ({
  x: i * 160, h: 25 + (i * 17) % 25
}));

const CLOUD_P = 7 * 260;
const MOUNT_P = 8 * 200;
const HILL_P  = 10 * 160;

function wrapPos(x, period) {
  let v = ((x % period) + period) % period;
  if (v > W + 50) v -= period;
  return v;
}

function drawBackground(avgSpeed) {
  let g = ctx.createLinearGradient(0, 0, 0, 320);
  g.addColorStop(0, '#87ceeb');
  g.addColorStop(1, '#